<?php
$action = $_REQUEST['action'];

if (!isset($_SESSION['login'])){ // si n'est pas connecté renvoie vers formulaire de connexion
    $action='connexion';
}else{
    if ($action == 'connexion'){
        $action = 'gestion';
    }
}

switch($action)
{
    case 'connexion':
    {
        if(isset($_POST['pseudo']) && isset($_POST['mdp'])){
            $pseudo = $_POST['pseudo'];
            $mdp = $_POST['mdp'];
            $resu = $pdo->testLogAdmin($pseudo, $mdp);
            if($resu[0]== 0){

                $message = "Erreur de connexion";
                include('vues/v_accueil.php');
            }else{
                $_SESSION['login'] = $_POST['pseudo'];
                echo "<h1>Vous allez être redirigé vers l'espace admin</h1>";
                include('vues/v_accueil.php');
                header("Refresh: 3; url=index.php?uc=administration&action=gestion");
            }
        }else{
            include("vues/v_accueil.php");
        }

        break;
    }
    case 'gestion':
        {
            $titre = "GESTION CLUB";
            include("vues/v_bandeAdmin.php");
            $lesClub = $pdo->afficheClub();
            include("vues/v_accueilAdmin.php");

            break;
        }

    case 'voirJoueur':
    {
        $titre = "GESTION JOUEUR";
        include("vues/v_bandeAdmin.php");
        $idclub = $_GET['idclub'];
        $lesJoueurs = $pdo->GetLesJoueurDuclub($idclub);
        include("vues/v_joueur.php");
        break;
    }

    case 'deconnexion':
    {
        include("vues/v_adminDeconnexion.php");

        break;
    }

    case 'ajoutClub':
    {
        include("vues/v_ajouterClub.php");
        if (isset($_POST['nom']))
        {
            $image=$_POST['image'];
            $nomclub=$_POST['nom'];
            $pdo->ajoutClub($nomclub, $image);
        }
        break;
    }

    case 'ajoutJoueur':
    {
        $titre = "AJOUTER JOUEUR";
        $idclub = $_GET['idclub'];
        $unclub = $pdo->GetLeClub($idclub);
        include("vues/v_bandeAdmin.php");
        if(isset($_POST['valider'])){
            $nom = $_POST['nom'];
            $prenom = $_POST['prenom'];

            $datenaiss = $_POST['datenaiss'];
            $photo = $_POST['photo'];
            $pdo->ajoutJoueur($nom, $prenom, $datenaiss, $idclub, $photo);
        }
        include("vues/v_ajouterJoueur.php");
        break;
    }

    case 'modifierJoueur' :
    {
        $titre = "MODIFIER JOUEUR";
        $idjoueur = $_GET['idjoueur'];
        if(isset($_POST['valider'])){
            $nom = $_POST['nom'];
            $prenom = $_POST['prenom'];
            $datenaiss = $_POST['datenaiss'];
            $pdo->modifieJoueur($idjoueur, $nom, $prenom, $datenaiss);
        }
        $unjoueur = $pdo->GetLeJoueur($idjoueur);
        include("vues/v_bandeAdmin.php");
        include("vues/v_modifierJoueur.php");
        break;
    }

    case 'supprimerJoueur' :
    {
        $titre = "SUPPRIMER JOUEUR";
        $idjoueur = $_GET['idjoueur'];
        $unjoueur = $pdo->GetLeJoueur($idjoueur);
        $leclub = $pdo->GetLeClubduJoueur($idjoueur);
        $idclub = $leclub['id_club'];

        if(isset($_POST['valider'])){
            $pdo->supprimeJoueur($idjoueur);
            $message = "Joueur supprimé, vous allez être redirigé vers l'accueil";
            header("Refresh: 2; url=index.php?uc=administration&action=voirJoueur&idclub=$idclub");
        }
        include("vues/v_bandeAdmin.php");
        include("vues/v_supprimerJoueur.php");

        break;
    }

    case 'transfererJoueur':
    {
        $titre = 'TRANSFERT JOUEUR';
        $idjoueur = $_GET['idjoueur'];
        $unjoueur = $pdo->GetLeJoueur($idjoueur);
        $unclub = $pdo->GetLeClubduJoueur($idjoueur);
        $lesClub = $pdo->afficheClub();
        if(isset($_POST['valider'])){
            $idclub = $_POST["club"];
            $pdo->transfertJoueur($idjoueur, $idclub);


        }
        include("vues/v_bandeAdmin.php");
        include("vues/v_transfererJoueur.php");
        break;
    }


}
?>