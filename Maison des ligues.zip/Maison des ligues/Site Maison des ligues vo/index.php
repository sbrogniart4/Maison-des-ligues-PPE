<?php
session_start();

require_once("util/fonctions.inc.php");
require_once("util/class.pdoLigue.inc.php");
include("vues/v_entete.php") ;
include("vues/v_bandeau.php") ;

if(!isset($_REQUEST['uc']))
    $uc = 'accueil';
else
    $uc = $_REQUEST['uc'];

$pdo = PdoLigue::getPdoligue();
switch($uc)
{
    case 'accueil':
    {include("vues/v_accueil.php");break;}
    case 'administration' :
    {
            include("controleurs/c_gestionLigue.php");
    break;}

}
include("vues/v_pied.php") ;
?>

