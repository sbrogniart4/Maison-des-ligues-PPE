<?php
/**
 * Classe d'accès aux données.

 * Utilise les services de la classe PDO
 * pour l'application maison des ligues
 * Les attributs sont tous statiques,
 * les 4 premiers pour la connexion
 * $monPdo de type PDO
 * $monPdoGsb qui contiendra l'unique instance de la classe
 *
*/

class PdoLigue
{
    private static $serveur='mysql:host=localhost';
    private static $bdd='dbname=ligue';
    private static $user='root' ;
    private static $mdp='' ;
    private static $monPdo;
    private static $monPdoligue = null;
    /**
     * Constructeur privé, crée l'instance de PDO qui sera sollicitée
     * pour toutes les méthodes de la classe
     */
    private function __construct()
    {
        PdoLigue::$monPdo = new PDO(Pdoligue::$serveur.';'.Pdoligue::$bdd, Pdoligue::$user, Pdoligue::$mdp);
        PdoLigue::$monPdo->query("SET CHARACTER SET utf8");
    }
    public function _destruct(){
        PdoLigue::$monPdo = null;
    }
    /**
     * Fonction statique qui crée l'unique instance de la classe
     *
     * Appel : $instancePdolafleur = PdoLafleur::getPdoLafleur();
     * @return l'unique objet de la classe PdoLafleur
     */
    public  static function getPdoligue()
    {
        if(Pdoligue::$monPdoligue == null)
        {
            Pdoligue::$monPdoligue= new PdoLigue();
        }
        return Pdoligue::$monPdoligue;
    }

    /**
     * Verification du login et du mdp
     * Retourne 0 si pas trouvé, 1 si ok
     * @param $pseudo
     * @param $mdp
     */
    public function testLogAdmin($pseudo, $mdp){
        $req = "select count(*) from membre where pseudo_membre = '$pseudo' and mdp_membre = '$mdp'";
        /*var_dump($req);*/
        $res = PdoLigue::$monPdo->query($req);
        $leResu = $res -> fetch();
        /*var_dump($leResu);*/
        return $leResu;
    }

    /* Fonction ajout de club
     *
     *
     */
    public function ajoutClub($nomclub, $image){
    $req = "insert into club values ('null','$nomclub','$image')";
    $res = PdoLigue::$monPdo->exec($req);
}

    /* Fonction getlesjoueurduclub
        Récupère les joueurs d'un club dont l'id du club est passé en parametre
     *
     */
    public function GetLesJoueurDuclub($idclub){
        $req = "select * from joueur where id_club='$idclub' order by nom_joueur";
        $res = PdoLigue::$monPdo->query($req);
        $resu = $res -> fetchAll();
        return $resu;
    }

    /* Fonction afficheclub
        recupere la liste de tous les club
     *
     */
    public function afficheClub(){
        $req = "select * from club order by nom_club";
        $res = PdoLigue::$monPdo->query($req);
        $resu = $res -> fetchAll();
        return $resu;
    }

    /* Fonction ajoutJoueur
        Ajout du nom, prenom, date de naissance , photo du joueur et l'id de son club
     *
     */
    public function ajoutJoueur($nom, $prenom, $datenaiss, $idclub, $photo){
        $req1 = "insert into joueur values ('null','$nom','$prenom', '$datenaiss', '$photo' , '$idclub')";
        $res = PdoLigue::$monPdo->exec($req1);

        $req2 = "select max(id_joueur) as idjoueur from joueur";
        $res = PdoLigue::$monPdo->query($req2);
        $resu = $res -> fetch();

        $idjoueur = $resu['idjoueur'];

        $req3 = "insert into inscrire values (NOW(),'$idjoueur','$idclub')";
        $res = PdoLigue::$monPdo->exec($req3);
    }

    /* Fonction modifieJoueur
        modifie le nom , le prenom , la datenaissance d'un joueur depuis son id
     *
     */
    public function modifieJoueur($idjoueur, $nom, $prenom, $datenaiss){
        $req = "update joueur set nom_joueur = '$nom', prenom_joueur = '$prenom', datenaiss_joueur = '$datenaiss' where id_joueur = '$idjoueur'";
        $res = PdoLigue::$monPdo->exec($req);
    }

    /* Fonction supprimeJoueur
        Supprime le joueur de la table inscrire
        puis supprime le joueur de la table joueur
     *
     */

    public function supprimeJoueur($idjoueur){
        $req1 = "delete from inscrire where id_joueur ='$idjoueur'";
        $req2 = "delete from joueur where id_joueur ='$idjoueur'";
        $res = PdoLigue::$monPdo->exec($req1);
        $res = PdoLigue::$monPdo->exec($req2);
    }

    /* Fonction transfertJoueur
        modifie l'id du club ou le joueur a été transféré
        insert une ligne dans inscrire pour pouvoir consulter l'historique
     *
     */

    public function transfertJoueur($idjoueur, $idclub){
        $req1 = "UPDATE joueur set id_club = '$idclub' where id_joueur='$idjoueur'";
        $res = PdoLigue::$monPdo->exec($req1);
        $req2 = "insert into inscrire values (NOW(),'$idjoueur','$idclub')";
        $res = PdoLigue::$monPdo->exec($req2);
    }

    /* Fonction getleJoueur
       Récupère les info d'un joueur depuis son id
    *
    */

    public function GetLeJoueur($id){
        $req = "select * from joueur where joueur.id_joueur='$id'";
        $res = PdoLigue::$monPdo->query($req);
        $resu = $res -> fetch();
        return $resu;
    }


    /* Fonction getleClub
       Récupère les info d'un club depuis son id
    *
    */
    public function GetLeClub($id){
        $req = "select * from club where id_club='$id'";
        $res = PdoLigue::$monPdo->query($req);
        $resu = $res -> fetch();
        return $resu;
    }

    /* Fonction getleClubduJoueur
        Récupère l'id et le nom du club du joueur
     *
     */

    public function GetLeClubduJoueur($id){
        $req = "select club.id_club, nom_club from club, inscrire where club.id_club = inscrire.id_club and inscrire.id_joueur='$id'";
        $res = PdoLigue::$monPdo->query($req);
        $resu = $res -> fetch();
        return $resu;
    }

    /* Fonction Gethistorique
        Recupere la liste des club que le joueur a frequenté
     *
     */

    public function Gethistorique($idjoueur){
        $req = "select nom_club from club, inscrire where club.id_club = inscrire.id_club and inscrire.id_joueur='$idjoueur'";
        $res = PdoLigue::$monPdo->query($req);
        $resu = $res -> fetchAll();
        return $resu;
    }
}
?>