<?php
session_unset();
session_destroy();
echo'<h1>Déconnexion en cours...</h1>';
header ("Refresh: 3;URL='index.php?uc=accueil'");
?>