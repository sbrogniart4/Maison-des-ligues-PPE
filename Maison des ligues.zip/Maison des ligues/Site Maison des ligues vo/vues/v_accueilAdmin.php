<div id="contenuClub">
    <ul>
        <?php
            foreach($lesClub as $unclub){ //affiche la liste de tout les club
                $idclub = $unclub['id_club'];
                $nomclub = $unclub['nom_club'];
                $imageclub = $unclub['image_club'];
                echo "<li>
                          <a href='index.php?uc=administration&action=voirJoueur&idclub=$idclub'>
                               <img src='".$imageclub."'/>
                               <p>".$nomclub."</p>
                          </a>
                      </li>";
            }
        ?>
    </ul>
</div>


