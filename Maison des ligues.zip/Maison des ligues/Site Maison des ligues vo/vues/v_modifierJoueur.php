<div id="ajoutjoueur">
    <form name="modifjoueur" method="POST">
        <fieldset>
            <legend>Modifier le joueur : <?php echo $unjoueur['nom_joueur']." "; echo $unjoueur['prenom_joueur'];?></legend>
            <p>
                <label for="nom">Nom du joueur :</label>
                <input id="nom" type="text" name="nom" size="30" maxlength="45" value="<?php echo $unjoueur['nom_joueur']; ?>">
            </p>
            <p>
                <label for="prenom">Prenom du joueur :</label>
                <input id="prenom" type="text" name="prenom" size="30" maxlength="45" value="<?php echo $unjoueur['prenom_joueur']; ?>">
            </p>
            <p>
                <label for="datenaiss">Date de naissance du joueur :</label>
                <input id="datenaiss" type="text" name="datenaiss" size="30" maxlength="45" value="<?php echo $unjoueur['datenaiss_joueur']; ?>">
            </p>
            <p>

                <input type="submit" value="Valider" name="valider">
                <input type="reset" value="Annuler" name="annuler">
            </p>
        </fieldset>
    </form>
</div>