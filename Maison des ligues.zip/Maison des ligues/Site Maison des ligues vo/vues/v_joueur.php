<script>
    var profiljoueur = "";
    profiljoueur = document.getElementById('profil_joueur');
    var fils = "";

    function afficheprofil(idjoueur){
        var profiljoueur = "";
        profiljoueur = document.getElementById('profil_joueur');
        for(i=3; i < profiljoueur.childNodes.length;i++){
            fils = profiljoueur.childNodes[i];
            fils.style.display='none';
        }
        profiljoueur.style.display='block';
        var infojoueur = "";
            infojoueur = document.getElementById(idjoueur);
            infojoueur.style.display='block';
    }

</script>
<div id='liste_joueur'>
    <ul>
    <?php
    foreach($lesJoueurs as $joueur){ // affiche la liste des joueurs du club
        $idjoueur = $joueur['id_joueur'];
        $nomjoueur = $joueur['nom_joueur'];
        $prenomjoueur = $joueur['prenom_joueur'];
        $datenaissj = $joueur['datenaiss_joueur'];
        $idclub = $joueur['id_club'];
        $photojoueur = $joueur['photo_joueur'];
        echo "<li class='joueur'><a onmouseover='afficheprofil($idjoueur); return false;'href='#'><p>".$nomjoueur." ".$prenomjoueur."</p></a></li>";
    }
    ?>
        <li class='joueur ajout'><a href="index.php?uc=administration&action=ajoutJoueur&idclub=<?php echo $idclub; ?>"><p>+ Ajouter joueur</p></a></li>
    </ul>
</div>
<div id='profil_joueur'>
    <p>Profil</p>
    <?php
    foreach($lesJoueurs as $joueur){
        $idjoueur = $joueur['id_joueur'];
        $nomjoueur = $joueur['nom_joueur'];
        $prenomjoueur = $joueur['prenom_joueur'];
        $datenaissj = $joueur['datenaiss_joueur'];
        $idclub = $joueur['id_club'];
        $photojoueur = $joueur['photo_joueur'];
        $historique = $pdo->Gethistorique($idjoueur); // recupere la liste des club que le joueur a fréquenté

        echo "<div style='display:none;' id='$idjoueur'>
                    <p><img src='$photojoueur'/></p>
                    <p>Nom : $nomjoueur</p>
                    <p>Prenom : $prenomjoueur</p>
                    <p>Date de naissance : $datenaissj</p>
                    <p>Historique : </p>";
        foreach($historique as $unclubvisite){
            $clubvisite = $unclubvisite['nom_club'];
            echo "<p>$clubvisite</p>"; // affiche la liste des club que le joueur a fréquenté
        }
        echo"
                    <a href='index.php?uc=administration&action=modifierJoueur&idjoueur=$idjoueur'>Modifier ce joueur</a>
                    <a href='index.php?uc=administration&action=supprimerJoueur&idjoueur=$idjoueur'>Supprimer  ce joueur</a>
                    <a href='index.php?uc=administration&action=transfererJoueur&idjoueur=$idjoueur'>Transférer ce joueur</a>
             </div>";
    }
    ?>
</div>
