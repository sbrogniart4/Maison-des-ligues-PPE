<h1>Formulaire d'ajout</h1>
<form name="ajoutClub" method="POST" action="">
    <label for="nom">Nom club</label>
    <input name='nom' type='text'>
    <input name='image' type='hidden' value='images/non-disponible.jpeg'>
    <input name='valider' type='submit'>

</form>