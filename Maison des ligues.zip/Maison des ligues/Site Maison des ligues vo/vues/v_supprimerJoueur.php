<form method='POST'>
    <?php if(isset($message)) echo '<p>'.$message.'</p>'; ?>
    <p>Voulez vous vraiment supprimer : <?php echo $unjoueur['nom_joueur']." ".$unjoueur['prenom_joueur'];?> ?</p>
    <p>
        <input type="hidden" value="<?php echo $unjoueur['id_joueur'] ?>" name="idjoueur">
        <input type="submit" value="Supprimer" name="valider">
        <a href="index.php?uc=administration&action=voirJoueur&idclub=<?php echo $idclub ?>">Annuler</a>
    </p>
</form>
