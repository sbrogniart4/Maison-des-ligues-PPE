

<div id='bande_admin'>
    <ul>
        <li><form name="form_recherche" method="POST" action="">
                <input type="search" id="rechercheform" placeholder="Rechercher">
                <input type='submit' name='ajouterClub'  value='Rechercher'>
            </form>
        </li>
        <li><a href="index.php?uc=administration&action=ajoutClub">Ajouter un club</a></li>
        <li><a href="index.php?uc=administration&action=gestion">Retour à l'accueil</a></li>



        <li class="droite">
            <div id='affich_login'><?php echo"Bonjour ".$_SESSION['login'] ;
                ?><a href="index.php?uc=administration&action=deconnexion"> Deconnexion</a>
            </div>
        </li>

    </ul>
    <br />
    <br />
    <h2><?php echo $titre ?></h2>
</div>





