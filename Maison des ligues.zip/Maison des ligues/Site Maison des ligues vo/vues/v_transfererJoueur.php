<div id="ajoutjoueur">
    <form name="modifjoueur" method="POST">
        <fieldset>
            <legend>Transférer le joueur : <?php echo $unjoueur['nom_joueur']." "; echo $unjoueur['prenom_joueur'];?></legend>

            <p>
                <label for="transfert">Transfert du joueur : </label>
                <?php echo $unjoueur['nom_joueur']; ?>
                Depuis <?php echo $unclub['nom_club']; ?> Vers
                <select name="club">
                    <?php
                        foreach($lesClub as $club){
                        $nomclub = $club['nom_club'];
                        $idclub = $club['id_club'];
                            if($unclub['nom_club'] != $nomclub){
                                echo "<option value = ".$idclub.">".$nomclub."</option>";
                            }
                        }
                    ?>
                </select>
            </p>
            <p>
                <input type="submit" value="Valider" name="valider">
                <input type="reset" value="Annuler" name="annuler">
            </p>
        </fieldset>
    </form>
</div>