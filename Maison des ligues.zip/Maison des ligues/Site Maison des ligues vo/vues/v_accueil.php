<div id='wrapper'>
    <?php if(isset($message)){
        echo $message;
}
?>
    <div id='connexion'>
        <h2>LOGIN</h2>
     <form name='connexion' method='POST' action='index.php?uc=administration&action=connexion'>
           <table>
           <tr>
               <td>
                   <label for="pseudo">Pseudo</label></td>
                 <td>
                   <input type='text' name='pseudo'></br></td>
              </tr>

              <tr>
                 <td>
                     <label for="mdp">Mot de passe</label></td>
                 <td>
                   <input type='password' name='mdp'></br></td>
             </tr>

                <tr>
                    <td>
                        <input type='submit' name='Valider'>
                    </td>
                </tr>
           </table>
      </form>

      </div>
</div>
