<div id='bandeau'>
    <div id='logo'>
        <img src="images/logo.png" alt="" id='logo'>
    </div>

    <div id='text_logo'>
        <h1><span> MAISON DES LIGUES</span></h1>
    </div>
</div>
<div id='wrapper'>