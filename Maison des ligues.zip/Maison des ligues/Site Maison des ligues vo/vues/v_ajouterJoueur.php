<div id="ajoutjoueur">
    <form name="ajoutjoueur" method="POST">
        <fieldset>
            <legend>Ajouter un joueur dans : <?php echo $unclub['nom_club']?></legend>
            <p>
                <label for="nom">Nom du joueur :</label>
                <input id="nom" type="text" name="nom" size="30" maxlength="45" >
            </p>
            <p>
                <label for="prenom">Prenom du joueur :</label>
                <input id="prenom" type="text" name="prenom" size="30" maxlength="45">
            </p>
            <p>
                <label for="datenaiss">Date de naissance du joueur :</label>
                <input id="datenaiss" type="text" name="datenaiss" size="30" maxlength="45">
            </p>
            <p>
                <input type="hidden" value="images/photo_joueur/joueur_inconnu.png" name="photo">
                <input type="submit" value="Valider" name="valider">
                <input type="reset" value="Annuler" name="annuler">
            </p>
        </fieldset>
    </form>
</div>